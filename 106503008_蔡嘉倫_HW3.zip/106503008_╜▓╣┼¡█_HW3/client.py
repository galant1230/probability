from socket import *

#伺服器資訊
HOST = '61.57.110.241'
PORT = 12000
#創建socket
clientSocket = socket(AF_INET,SOCK_STREAM)
clientSocket.connect((HOST, PORT))
#http的格式，為了取得index.html檔案，後面是可接收的格式
request = "GET /test.html HTTP/1.1 \r\n HOST:123.241.214.108  \r\n Accept:text.html \r\n\r\n " 
clientSocket.send(request.encode())#將形式encode成utp-8(byte->str)
result=clientSocket.recv(4096)
print(result.decode())#再從utp-8轉為ASCII(str_>byte)

clientSocket.close()