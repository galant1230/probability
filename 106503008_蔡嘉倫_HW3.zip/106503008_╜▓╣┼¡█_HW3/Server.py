# -*- coding: utf-8 -*-
"""
Created on Sat Nov 30 14:42:39 2019

@author: user
"""
#由於 socket 模塊中有太多的屬性。我們在這裏破例使用了‘from module import *‘語句。
#使用 ‘from socket import *‘,我們就把 socket 模塊裏的所有屬性都帶到我們的命名空間
#例如在之後的城市中就不需要在前頭加上socket此屬性，這樣就能大幅減短我們的code。
from socket import * 
#開一個不是1200以前的port(SU使用的port)，以便不會重複使用到      
serverPort=12000
serverName='123.241.214.108'
#AF_INET: 跟外面網路建立聯繫,也就是IPv4,TCP,UDP要用這種形式
#SOCK_STREAM: 會確保資料正確的流到對方, 像是資料串流的用法, 此法是用TCP
serverSocket = socket(AF_INET, SOCK_STREAM)
#讓這個socket綁訂到我的電腦(ip/port)的虛擬ip，因為之後會以終端機進行client
#並連線至我的電腦，此方法使Server能要求用此位址將Client的訊息傳送進來
serverSocket.bind((serverName, serverPort))
#listen設定最多可以讓幾個連線數，通常只需要5個就能讓TCP連線成功執行                                           
serverSocket.listen(5)                     
#要做成Server, 要一直不停的聆聽client端的資料，因此使用while迴圈     
while 1:                                   
    print (('The server is ready to receive'))
    #簡單一點可以把accept訊息做在while loop裡面
    connectionSocket, addr = serverSocket.accept()
    #try...except:通常也能用於開檔案上，若程式中打算開啟檔案，然而實際檔名並不存在，
    #這種情況下，我們需要的是例外發生後的處理動作，而非中止程式的執行。
    #因此我們在此處選擇使用try..except的方式撰寫
    #當except發生時，程式會直接跳過下面的code直接跳到except部分處理 
    try:         
        #在此處建立一個能接收4096字元的buffer
        message = connectionSocket.recv(4096)                                                           
        #split能將所需要的字串換成是list，而在http的請求格式中，若是使用GET，則第一部分字串是GET，
        #而第二部分是就是路徑(somedir)，因此用[1]找到這段路徑令為檔案名稱，([0]就會代表是第一個字串GET)
        filename = message.split()[1] 
        #因為在HTTP的request前面都會加上'/'這個字元，(HTTP的格式:GET/somedir/page.html HTTP/1.1)
        #因此我們從第二個字元開始找尋路徑
        f = open(filename[1:])
        #此時增加一個變數作為整個檔案內容的暫時緩衝區
        outputdata = f.read()
        f.close()
        #將HTTPresponse的標頭檔送到connectionSocket
        connectionSocket.send('HTTP/1.0 200 OK\nContent-Type: text/html\n\n'.encode())
        #將Client所需要的資料傳到socket
        #range(start, stop[, step]):可建立出一個整數列表，最常用於for迴圈中
        #len(list)，list是要計算的元素列表
        #因此就是將檔案中的所有內容經過for迴圈的方始獲得，並送到connectionSocke
        for i in range(0, len(outputdata)):
            connectionSocket.send(outputdata[i].encode())
            connectionSocket.send("\r\n".encode())
        #關閉connectionSocket，但此時welcome socket仍然存在
        connectionSocket.close()
        print(filename,"delivered")
    except IOError:
        #當檔案找不到時會使用except來做處理
        print(filename,"NOT found")
        connectionSocket.send('HTTP/1.1 404 Not Found\nContent-Type: text/html\n\n'.encode())
        connectionSocket.send("\r\n".encode())
        #關閉connectionSocket，但此時welcome socket仍然存在
        connectionSocket.close()
        print("file can not be found")
serverSocket.close() 
